<?php

/**
 * @file
 * Template that renders a part of the node form
 */
?>
<div class="<?php print $class; ?>">
  <?php print drupal_render_children($form); ?>
</div>